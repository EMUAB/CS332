CS332 Lab9
==================================

Same as the included forkexecvp.c but if the child is suspended or interrupted by Ctrl+C or Ctrl+Z,
 the parent requires that it be killed with Ctrl+\\ or the equivalent signal.

Compile
------------------

"make"

Usage
------------------

"./lab9 \<command> [args]"
