## CS332 Lab5
Prints a tree of the given directory's files and subdirectories' files

**Compile** with "make"

**Usage**: "./lab5 \<dirname>"